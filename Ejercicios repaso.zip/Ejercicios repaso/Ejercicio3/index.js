import {Editor} from "./editor.js";
let editor = new Editor();
let parrafo1 = document.getElementById("parrafo1");
var btnAdd = document.querySelector('.añadir');
btnAdd.addEventListener('click', () => {
        editor.add();
});
let contenido1 = parrafo1.innerHTML;
var btn1 = document.querySelector('.btnEdit1');
btn1.addEventListener('click', () => {
        editor.init(parrafo1, contenido1)
});
let parrafo2 = document.getElementById("parrafo2");
let contenido2 = parrafo2.innerHTML;
var btn2 = document.querySelector('.btnEdit2');
btn2.addEventListener('click', () => {
        editor.init(parrafo2, contenido2)
});
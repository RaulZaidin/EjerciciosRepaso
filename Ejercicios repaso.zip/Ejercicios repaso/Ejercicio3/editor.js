class Editor{
    constructor(){
    }
    init(parrafo, contenido){
        let textarea = document.createElement("textarea");
        parrafo.appendChild(textarea);
        textarea.value = contenido;
        let btnAceptar = document.createElement("button");
        let btnCancelar = document.createElement("button");
        btnAceptar.innerHTML = "Aceptar";
        btnCancelar.innerHTML = "Cancelar";
        parrafo.appendChild(btnAceptar);
        parrafo.appendChild(btnCancelar);
        btnAceptar.addEventListener('click', () => {
            let contenidoArea = textarea.value;
            this.save(parrafo,contenidoArea, btnAceptar, btnCancelar, textarea);
            
    });
    btnCancelar.addEventListener('click', () => {
        this.exit(parrafo, btnAceptar, btnCancelar, textarea)
});
    }
    save(parrafo, contenidoArea){
        parrafo.innerHTML = ' ';
        parrafo.innerHTML = contenidoArea;
    }
    exit(parrafo, btnAceptar, btnCancelar, textarea){
        parrafo.removeChild(btnAceptar);
        parrafo.removeChild(btnCancelar);
        parrafo.removeChild(textarea);
    }
    add(){
        let input = document.createElement("input");
        input.type = "text";
        document.getElementById("addParrafos").appendChild(input);
        let btnAdd = document.createElement("button");
        btnAdd.innerHTML = "Añadir";
        document.getElementById("addParrafos").appendChild(btnAdd);
        btnAdd.addEventListener('click', () => {
            let contenidoInput = input.value;
            var text = document.createTextNode(contenidoInput);                                   
            document.getElementById("addParrafos").appendChild(text); 
    });

        
        
        

    }
}
export {Editor};
class Calculadora{
    constructor(){

    }
    init(n1, n2, signo){
        let resultado;
        if(signo == '+'){
            resultado = n1 + n2;
        }else if( signo == '-'){
            resultado = n1 - n2;
        }else if(signo == '*'){
            resultado = n1 * n2;
        }else if(signo == '/'){
            resultado = n1 / n2;
        }
        document.querySelector('#numeroResultado').innerHTML = resultado;
        let cadena = n1 + " " + signo + " " + n2 + " = " + resultado + " \n ";
        var text = document.createTextNode(cadena);                                   
        document.getElementById("historial").appendChild(text); 
        
    }

}
export {Calculadora};
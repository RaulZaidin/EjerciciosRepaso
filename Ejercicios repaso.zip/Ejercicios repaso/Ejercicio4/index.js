import {Calculadora} from "./calculadora.js";
let calculadora = new Calculadora();
document.querySelector('#btnCalcular').addEventListener('click', () =>{
    const n1 = parseInt(document.querySelector('#numero1').value);
    const n2 = parseInt(document.querySelector('#numero2').value);
    const signo = document.querySelector('#signo').value;
    calculadora.init(n1, n2, signo);
});
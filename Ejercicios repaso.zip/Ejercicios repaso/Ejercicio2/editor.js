class Editor{
    constructor(){
    }
    init(parrafo, contenido){
        let textarea = document.createElement("textarea");
        parrafo.appendChild(textarea);
        textarea.value = contenido;
        let btnAceptar = document.createElement("button");
        let btnCancelar = document.createElement("button");
        btnAceptar.innerHTML = "Aceptar";
        btnCancelar.innerHTML = "Cancelar";
        parrafo.appendChild(btnAceptar);
        parrafo.appendChild(btnCancelar);
        btnAceptar.addEventListener('click', () => {
            let contenidoArea = textarea.value;
            this.save(parrafo,contenidoArea, btnAceptar, btnCancelar, textarea);
            
    });
    btnCancelar.addEventListener('click', () => {
        this.exit(parrafo, btnAceptar, btnCancelar, textarea)
});
    }
    save(parrafo, contenidoArea,btnAceptar, btnCancelar, textarea){
        parrafo.innerHTML = ' ';
        parrafo.innerHTML = contenidoArea;
    }
    exit(parrafo, btnAceptar, btnCancelar, textarea){
        parrafo.removeChild(btnAceptar);
        parrafo.removeChild(btnCancelar);
        parrafo.removeChild(textarea);
    }
}
export {Editor};
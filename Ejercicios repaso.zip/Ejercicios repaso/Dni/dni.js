class Dni{
    constructor(){
    }
    init(dni){
        var letras = ['T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z', 'S', 'Q', 'V',
'H', 'L', 'C', 'K', 'E', 'T'];

        if(dni.length === 0){
            alert("Has introducido un dato no valido");
        }else if(dni.length < 9 || dni.length > 9){
            alert("Has introducido un dato no valido");
        }else{
            var letra = dni.charAt(8);
            var cadena = dni.slice(0,8);
            if(letras.includes(letra)==true){
                cadena = cadena % 23;
                console.log(cadena)
                if(letras[cadena]==letra){
                    alert("El dni es correcto");
                }else{
                    alert("El dni no es valido");
                }
            }
        }
    }

}
export {Dni};
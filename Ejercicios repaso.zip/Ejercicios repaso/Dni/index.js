import {Dni} from "./dni.js";
let dni = new Dni();
let dnifield = document.getElementById("dni");
var btn = document.querySelector('.btn');
btn.addEventListener('click', () => {
        dni.init(dnifield.value);
});